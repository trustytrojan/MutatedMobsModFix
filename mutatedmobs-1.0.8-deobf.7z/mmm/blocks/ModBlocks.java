//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "G:\t\MutatedMobsModFix\Minecraft-Deobfuscator3000\1.12 stable mappings"!

//Decompiled by Procyon!

package mmm.blocks;

import net.minecraft.block.*;
import java.util.*;

public class ModBlocks
{
    public static final List<Block> Blocks;
    
    static {
        Blocks = new ArrayList<Block>();
    }
}
