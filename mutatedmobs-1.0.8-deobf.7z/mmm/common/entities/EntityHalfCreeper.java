//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "G:\t\MutatedMobsModFix\Minecraft-Deobfuscator3000\1.12 stable mappings"!

//Decompiled by Procyon!

package mmm.common.entities;

import net.minecraft.entity.monster.*;
import mmm.common.entities.mobs.interfaces.*;
import net.minecraft.world.*;

public class EntityHalfCreeper extends EntityCreeper implements IMutant
{
    public EntityHalfCreeper(final World worldIn) {
        super(worldIn);
    }
}
