//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "G:\t\MutatedMobsModFix\Minecraft-Deobfuscator3000\1.12 stable mappings"!

//Decompiled by Procyon!

package mmm.common.proxy;

import mmm.common.items.*;
import net.minecraftforge.fml.common.event.*;

public class CommonProxy
{
    public void preInit(final FMLPreInitializationEvent e) {
        ModItems.register();
    }
    
    public void init(final FMLInitializationEvent e) {
    }
    
    public void postInit(final FMLPostInitializationEvent e) {
    }
    
    public void registerRenders() {
    }
}
